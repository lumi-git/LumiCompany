# Lethal plugin

Have fun with thus fun plugin :D 
